#' Title
#'
#' @param x is a vector or data.frame
#'
#' @return a vector or data.frame
#' @export
#'
#' @examples
#' yy=apply(xx,1,outler)

outlier=function(x) {
  qnt=quantile(x,probs=c(.25,.75),na.rm=TRUE)
  range_u=qnt[2]+1.5*(qnt[2]-qnt[1])
  range_d=qnt[1]-1.5*(qnt[2]-qnt[1])
  x[which(x<range_d)] = NA
  x[which(x>range_u)] = NA
  return (x)
}
